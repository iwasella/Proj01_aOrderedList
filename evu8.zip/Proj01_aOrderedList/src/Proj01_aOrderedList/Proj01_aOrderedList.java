package Proj01_aOrderedList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;


// Phase 1: Create a class aOrderedList that will contain a 
// partially filled array to keep sorted with each insertion and deletion


/**
* <Contains the main method to run the code>
* 
* CSC 1351 Programming Project No <1>
7
* Section <2>
*
* @author <The Ella Vu>
* @since <March 17>
*
*/
public class Proj01_aOrderedList {

	public static void main(String[] args) throws FileNotFoundException {
	
	boolean filefound = false;
	boolean go = true;	
	while(go) {	
			Scanner input = new Scanner(System.in);
			
			// getting user input from Scanner method
			System.out.println("Enter input filename");
			String name = input.nextLine();
			Scanner scanner = GetInputFile(name);
			String decision = scanner.nextLine();
	
			// will continue or break loop depending on scanner return
			if(decision.equalsIgnoreCase("N")) {
		throw new FileNotFoundException("End");
			} else if (decision.equalsIgnoreCase("Y")){
				go = true;
			} else if(name.equals("InputCarData.txt")) {
				go = false;
			} else {
				System.out.println("That is not a valid response.");
				go = true;
			}
			

	}
	
	
	
		// Adding an aOrderedList object to the main program
		aOrderedList orderedList = new aOrderedList();
	
		// Getting file and scanning its contents
		File inputFile = new File("InputCarData.txt");
		Scanner scan = new Scanner(inputFile);
		List<Car> cars = new ArrayList<>(); 
		
		// for ever line of data in the input file
		int count = 0; //counting the amount of objects added and removed each time
		while(scan.hasNextLine()) {
			
			// we turn the entire line into a string
			// we separate the string into a String list
			// we assign values from the String list into the variables
			String line = scan.nextLine();
			String[] parts = line.split(",");
			
			if(parts.length == 4) {		
				
				int price = 0; //initizalizing variables
				int year = 0;
				
				// WILL ONLY ADD OBJECT IF A is at the beginning
				if(parts[0].contentEquals("A"))
				{
					String make = parts[1];
					// Turning the stringed numbers into numbers
					year = Integer.parseInt(parts[2]);
					price = Integer.parseInt(parts[3]); 
					
					// adding to arrayList
					cars.add(new Car(make,year,price));
					
					// adding to orderedList
					orderedList.add(new Car(make,year,price));
					count++;
				} 
				
				
			} else if(parts.length == 2) {
				// ILL DELETE AN OBJECT at a Specified integer
				if(parts[0].contentEquals("D")) {
					int indexToRemove = Integer.parseInt(parts[1]);
					orderedList.remove(indexToRemove);
					count--;
				}
				
			}
				else if(parts.length == 3) {
					// Delete an object only if it haas a matching make and year
					if(parts[0].contentEquals("D")) {
			            String make = parts[1];
			            int year = Integer.parseInt(parts[2]);
			            
			            int indexToRemove = -1;
			            // finding for every index in the car array that matches the make and year
			            for(int i = 0; i< cars.size(); i++) {
			            	Car car = cars.get(i);
			            	 if (car.getMake().equalsIgnoreCase(make) && car.getYear() == year) {
			            		 indexToRemove = i;
			            		 break;
			            	 }
			            }
			            
			            if(indexToRemove != -1 ) {
			                cars.remove(indexToRemove);
			                orderedList.remove(indexToRemove);
			            	count--;
			            }
					}
				}
			
			
		}
		
		
		//Creating PrintWriter object
		System.out.println("Enter output filename");
		Scanner scanning = new Scanner(System.in);
		String outputname = scanning.nextLine();
		PrintWriter outfile = GetOutputFile(outputname);
		
		// Writing data into the output file
		//
		
		outfile.println(orderedList);
		
		// Making sure that any buffered data is entered immediately
		// This wil help refresh the data
		outfile.flush();
		outfile.close();
		
		// Printing every line in the outputfile
		File yes = new File("OutputCarData.txt");
		
		
		System.out.printf("Number of cars: %d", count);
		Scanner scam = new Scanner(yes);
		while(scam.hasNextLine()) {
			String line = scam.nextLine();
			line =line.replace("[", "");
			line = line.replace("]", "");
			//line = line.replace(";", "");
			line = line.replace(",", "");
			line = line.replace("Make: ", "");
			line = line.replace("Year: ", "");
			line = line.replace("Price: ", "");
			
			// Splitting that ordered list into an array  of strings
			String[] parts = line.split(";");
			
			// Dividing each string to locate Make, Year, and Price
			for(int i =0; i < parts.length; i++) {
				String[] furtherParted = parts[i].split(" ");
				String labelmake = furtherParted[0];
				int labelyear = Integer.parseInt(furtherParted[1]);
				int labelprice = Integer.parseInt(furtherParted[2]);
				System.out.printf("\nMake: %15s",labelmake);
				System.out.printf("\nYear: %15d",labelyear);
				//Reformatted the label price before I adjusted the distance it is
				System.out.printf("\nPrice: %15s",String.format("$%,d", labelprice));
				System.out.println("\n");
			}

		
		}

		
	}	
	
	
	

	/**
	* <Prompt user for file names and returns a scanner object ready for input>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException{
		File file = new File(UserPrompt);
		if( file.exists()) {
			System.out.println("File Exists");
			return new Scanner(file);
		}else
		System.out.println("File specified <" + UserPrompt + "> does not exist."
				+ " Would you like to continue? <Y/N>");
		return new Scanner(System.in);
	}
	
	/**
	* <Prompt user for file names and returns printwriter object for output>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1>
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException{
		String filename = UserPrompt;
		while(true) {	
		File output = new File(filename);
		
		// returns a print writer if File is found
		if(output.exists()) {
			return new PrintWriter(output);
		}
		
		// will find different file name if file is not found
		else {
			System.out.println("File specified <" + UserPrompt + "> does not exist."
					+ " Would you like to continue? <Y/N>");
			Scanner scan = new Scanner(System.in);	
			String input = scan.nextLine();
		
		
				if(input.equalsIgnoreCase("N")) {
					throw new FileNotFoundException("End");
				} else if (input.equalsIgnoreCase("Y")){
					System.out.println("Enter input filename");	
					Scanner scanned = new Scanner(System.in);				
					filename = scanned.nextLine();
				} else {
					System.out.println("That is not a valid response.");
				}
			

			}
		
		}


	}
		
		
/**
* <Class for creating a car object>
* 
*
* CSC 1351 Programming Project No <1>
7
* Section <2>
*
* @author <The Ella Vu>
* @since <March 17>
*
*/
static class Car implements Comparable<Car>{

	//Private Members
	protected String make;
	protected int year;
	protected int price;
	
	
	//Public Methods
	
	//Constructor
	public Car(String Make, int Year, int Price) {
		this.make = Make;
		this.year = Year;
		this.price = Price;
	}
	
	/**
	* <Return make>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	public String getMake() {
		return make;
	}
	
	/**
	* <Return year>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	public int getYear() {
		return year;
	}
	
	/**
	* <Return price>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	public int getPrice() {
		return price;
	}

	/**
	* <Comparing make of an object to another>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	public int compareTo(Car other) {
		
		// we are comparing the string of a current object
		// to the string of another object 
		return this.make.compareTo(other.getMake());
	}
	
	/**
	* <Reutrning an object as a string>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	public String toString() {
		String CarInfo = "Make: " + this.make
				+ ", Year: " + this.year 
				+ ", Price: " + this.price + ";";
		return CarInfo;
	}

	
	

}

/**
* <Create an object of an ordered list>
* 
*
* CSC 1351 Programming Project No <1>
7
* Section <2>
*
* @author <The Ella Vu>
* @since <March 17>
*
*/
static class aOrderedList{

	private final int SIZEINCREMENTS = 20; // size increments for 									//increasing ordered list
	private Comparable[] oList; // the ordered list
	private int listSize;// the size of the ordered list
	private int numObjects; // the number of objects in the ordered list
	private int curr; //index of current element accessed via iterator methods
	
    private Iterator<Comparable> iterator;

    //Constructor
	public aOrderedList(){
		this.numObjects = 0;
		this.listSize = this.SIZEINCREMENTS;
		this.oList = new Comparable[SIZEINCREMENTS];
        this.iterator = Arrays.asList(oList).iterator();

	}
	
	/**
	* <adds object to sorted array in correct position to maintain sorted order
>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	void add(Comparable newCar) {
		
		// resize array if too small
		if(numObjects >= listSize -1) {
			System.out.println("Resizing array.");
			Comparable[] newValues = Arrays.copyOf(oList, 2 * SIZEINCREMENTS);
			oList = newValues;
			listSize += SIZEINCREMENTS;
		} 
		oList[numObjects] = newCar;
		numObjects++;
		
		
	}
	
	/**
	* <converts ordered list to String>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	public String toString(){
		
		// for every object in my list, I will call the toString method from the Car class
		String result = "[";
		for (int i = 0; i < numObjects; i++) {
			result += oList[i].toString();
			// if the object is not last, add a comma
			if(i < numObjects -1) {
				result += ",";
			}
		}
		result += "]";
		return	result;}
	
	/**
	* <gives size of list>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	int size() {
		return numObjects;
	}
	
	/**
	* <returns object located at a given index>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	Comparable get(int index) {
		return oList[index];
	}
	
	/**
	* <checks if ordered list is empty>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	boolean isEmpty() {
		if(oList.length == 0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	* <removes object from a list when given index>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	void remove(int index) {
		// creating new array with one less element than original array
		Comparable newValues[] = new Comparable[oList.length -1];	
		for (int i = 0,  j = 0; i < oList.length; i++ ) {
			// Adding elements to new array except for the one we need to remove
			if(i != index) {
				newValues[j++] = oList[i];
			}
		}
		// updating list and number of objects in list
		oList = newValues;
		numObjects--;
	
}	
	/**
	* <resets iterator parameters that the "next" element is the first element for the array, if any>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	void reset() {
        this.iterator = Arrays.asList(oList).iterator();

	}
	
	/**
	* <Returns the next element in the iteration>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	Comparable next() {
		return iterator.next();
		
	}
	
	/**
	* <Returns true if the iteration has more elements to iterate through>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	boolean hasNext() {
		return iterator.hasNext();
		
	}
	
	/**
	* <Removed the last element returned by the next() method>
	*
	* CSC 1351 Programming Project No <1>
	* Section <1
	*
	* @author <The Ella Vu>
	* @since <March 17>
	*
	*/
	void remove() {
		iterator.remove();
	}



}
}


